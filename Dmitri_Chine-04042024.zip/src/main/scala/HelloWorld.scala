package fr.esgi.funcProg

object HelloWorld {
  def main(args: Array[String]): Unit = {
    println("Hello, world ! This is my scala project!")
  }
}
